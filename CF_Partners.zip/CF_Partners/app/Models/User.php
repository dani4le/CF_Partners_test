<?php

namespace App\Models;

use CodeIgniter\Model;

class User extends Model
{
    protected $table = 'users';
	protected $primaryKey = 'id';
	protected $allowedFields = ['id', 'firstname', 'lastname', 'email', 'mobile', 'username', 'password'];
	
	public function getFields(){
		return $this->allowedFields;
    }
	public function getAll(){
		return $this->findAll();
    }
}