<?php

namespace App\Controllers;
use App\Models\User;

class Test extends BaseController
{
    public function index(){	//all the information about users will be shown in the homepage
        $model = model(User::class);
        $data['users'] = $model->getAll();
		$data['fields'] = $model->getFields();
		return view('test_home', $data);
    }
    public function save(){
        $post = $this->request->getRawInput();
		foreach($post as $key => $value){	//backend validation of the data received before going to the DB
			$value = trim($value);
			if(!empty($value)){
				if(str_ends_with($key, 'name') && !preg_match("/^\b([-,a-z. ']+[ ]*)+$/", $value)) $errors[$key] = 'Incorrect';
				else if($key == 'email' && !preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/", $value)) $errors[$key] = 'Incorrect';
				else if($key == 'mobile' && !preg_match("/^([+]\d{2})?\d{10,13}$/", $value)) $errors[$key] = 'Incorrect';
				else if($key == 'password'){
					if(strlen($value) < 3) $errors[$key] = 'Under min length';
					else $value = password_hash($value, PASSWORD_BCRYPT);
				}
				$post[$key] = $value;
			}
			else $errors[$key] = 'Empty';	//cannot save on DB empty information
		}
		$model = model(User::class);
		if(empty($errors)){
			if(isset($post['id'])) echo $model->update($post['id'], $post) ? 'updated' : 0;
			else echo $model->insert($post);	//if the dataset has an id it means that the operation is an update, otherwise a create, I could have use the save() method from codeigniter but it doesn't return the new key after insertion on DB
		}
		else echo json_encode($errors);
    }
    public function delete(){
        $post = $this->request->getRawInput();
		$model = model(User::class);
		echo $model->delete($post['id'], true);
    }
}
