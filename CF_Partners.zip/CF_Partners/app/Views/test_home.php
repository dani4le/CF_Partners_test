<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daniele Alesi test</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
	<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
	<style>
		#myTable tr > *{
			line-height: 1rem;
			max-width: 100px;
			width: 14%;
		}
		#myTable td:first-child{
			width: auto;
		}
		#myTable td:last-child{
			display: flex;
			max-width: unset;
			width: 150px;
			justify-content: space-between;
		}
		#myTable input{
			width: 100%;
		}
		#myTable button{
			width: 73px;
		}
		#myTable div.error{
			color: red;
			font-size: 75%;
		}
    </style>
</head>
<body>
<?php
	//saving recurring HTML elements as PHP variables
	$pwd_mask = '****';
	$validation = '<div class="error"></div>';
	ob_start();
?>
<td><button class="btn btn-primary edit" onclick="setEditable(true, this);">Edit</button><button class="btn btn-secondary delete">Delete</button><button class="btn btn-success save d-none">Save</button><button class="btn btn-secondary cancel d-none" onclick="setEditable(null, this);">Cancel</button></td><?php $buttons = ob_get_clean(); ?>
	<table id="myTable" class="table-striped table-bordered">
		<thead>
			<tr>
				<?php foreach($fields as $field): ?>
					<th><?= ucfirst($field) ?></th>
				<?php endforeach ?>
				<th/>
			</tr>
		</thead>
		<tbody>
			<?php if(!empty($users) && is_array($users)): ?>
				<?php foreach($users as $user): ?>
					<tr>
						<?php foreach($fields as $field): ?>
							<?php if($field != 'password'): ?>
							<td><?= $user[$field] ?></td>
							<?php else: ?>
							<td><?= $pwd_mask ?></td>
							<?php endif ?>
						<?php endforeach ?>
						<?= $buttons ?>
					</tr>
				<?php endforeach ?>
			<?php endif ?>
		</tbody>
		<tfoot>
			<tr>
				<?php foreach($fields as $field): ?>
					<td>
						<?php if($field != 'id'): ?>
							<input name="<?= $field ?>" <?php if($field == 'password'): ?> type="<?= $field ?>" <?php endif ?> />
							<?= $validation ?>
						<?php endif ?>
					</td>
				<?php endforeach ?>
				<td><button class="btn btn-success save">Save</button></td>
			</tr>
		</tfoot>
	</table>
	<script>
		let table = new DataTable('#myTable', {
			searching: false,
			columns: [	//defining classes and orderability for the data in the table
			<?php foreach($fields as $field): ?>
				{ className: '<?= $field ?>'<?php if($field == 'password'): ?>, orderable: false<?php endif ?> },
				<?php endforeach ?>
				{ orderable: false }
			]
		});
		var tbody = $('.dataTables_empty').parent().parent().hide(); //if the table is empty don't show Datatables default message for empty table
		
		$('#myTable').on('click', '.save', function(e){
			var inputs = $(this).closest('tr').find('input');
			if(validate(inputs)){	//after data validation let's build the params string for the request when saving data on DB
				var params = '';
				inputs.each(function(i){
					params += '&' + this.name + '=' + this.value;
				});
				$.post('test/save', params, function(data){
					if(data > 0){
						var new_row = [data];	//when a new row has been created on DB, the related id is returned and the new row can be assembled for the Datatables HTML element
						inputs.each(function(i){
							if(this.name == 'password') this.value = '<?= $pwd_mask ?>';
							new_row.push(this.value);
							this.value = '';
						});
						new_row.push('<?= $buttons ?>');
						table.row.add(new_row).draw();
						tbody.show();	//if the table had no data before this insertion, the tbody was hidden and then it needs to be shown
					}
					else if(data == "updated") setEditable(false, e.target);
				}).fail(function () {
					alert('Database connection not available, contact the administrator');
				});
			}
		});
		$('#myTable').on('click', '.delete', function(e){
			const del_row = $(this).closest('tr'), field = 'id';
			const params = field + '=' + del_row.find('.' + field).text();
			$.post('test/delete', params, function(data) {
				if(data == 1){
					if(tbody.length == 0) tbody = $('#myTable tbody');
					tbody.toggle(tbody.find('tr').length > 1);	//if the data to remove is the only row on the table, hide the tbody to prevent the display of Datatables default message for empty table
					table.row(del_row).remove().draw();
				}
			});
		});
		function setEditable(flag, source){	//method to make a table row editable and viceversa, it supports also abortion of modification made inside of the input HTML elements
			source = $(source);
			var fields = source.closest('tr').find('td:lt(-1)');	//don't take the last cell of the row
			fields.each(function(i){
				const name = this.className.trim().split(' ')[0];	//avoid classes eventually added by Datatables
				if(flag){	//if flag is true go from plain text to input fields
					var content = '<input name="' + name + '" ';
					if(name == 'password')
						content += 'type="' + name + '" />';
					else{
						if(name == 'id') content = this.innerHTML + content + 'type="hidden" ';
						content += 'value="' + this.innerHTML + '" />';
					}
					$(this).html(content + '<?= $validation ?>');	//insert elements to show validation messages for every input field
				}
				else{	//go from input fields to plain text, if flag is null take original values initially set for the input fields, user aborted the modification, if flag is false take the current value set by user in the input fields, user saved on DB
					value = name.includes('password') ? '<?= $pwd_mask ?>' : flag === null ? $(this).find('input').attr('value') : $(this).find('input').val();
					$(this).html(value);
				}

			});
			source.parent().find('button').toggleClass('d-none');	//show when needed Edit & Delete or Save & Cancel buttons
		}
		function validate(inputs){	//method used for frontend validation, called when inserting or updating data on DB
			isValid = 0;
			inputs.each(function(i){
				const value = this.value = this.value.trim(), name = this.name;
				if(value == '')	//check empty value regardless of white spaces
					$(this).next().text('Fill the value');
				else if(name.endsWith('name') && !(/^\b([-,a-z. ']+[ ]*)+$/).test(value))
					$(this).next().text('Incorrect ' + name);
				else if(name == 'email'){
					const emails = $(this).closest('tr').siblings().find('.email');
					if(!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/).test(value))
						$(this).next().text('Incorrect ' + name);
					else if(emails.filter(':contains("' + value + '")').length > 0 || emails.find('input').val() == value)
						$(this).next().text('Email already in use');	//wanted to avoid different users with same email address, permitted for mobile number
					else{
						$(this).next().text('');
						isValid++;
					}
				}
				else if(name == 'mobile' && !(/^([+]\d{2})?\d{10,13}$/).test(value))
					$(this).next().text('Incorrect ' + name);
				else if(name == 'password' && value.length < 3)
					$(this).next().text('Under min length');
				else{
					$(this).next().text('');
					isValid++;
				}
			});
			return inputs.length == isValid;
		}
	</script>
</body>
</html>
